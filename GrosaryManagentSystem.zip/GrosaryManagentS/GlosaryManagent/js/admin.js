$(document).ready(function () {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const products = JSON.parse(localStorage.getItem('products')) || [];

    // Load Vendor Users
    function loadVendors(searchQuery = '') {
        const vendorTableBody = $('#vendorTable tbody').empty();

        users.forEach((user, index) => {
            if (
                user.role === 'vendor' &&
                (!searchQuery ||
                    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    user.email.toLowerCase().includes(searchQuery.toLowerCase()))
            ) {
                const userRow = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-danger btn-sm delete-user" data-email="${user.email}">Delete</button>
                        </td>
                    </tr>
                `;
                vendorTableBody.append(userRow);
            }
        });

        // Delete user event
        $('.delete-user').click(function () {
            const email = $(this).data('email');
            const updatedUsers = users.filter(user => user.email !== email);
            localStorage.setItem('users', JSON.stringify(updatedUsers));
            alert('Vendor deleted successfully!');
            loadVendors();
        });
    }

    // Load Customer Users
    function loadCustomers(searchQuery = '') {
        const customerTableBody = $('#customerTable tbody').empty();

        users.forEach((user, index) => {
            if (
                user.role === 'customer' &&
                (!searchQuery ||
                    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    user.email.toLowerCase().includes(searchQuery.toLowerCase()))
            ) {
                const userRow = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-danger btn-sm delete-user" data-email="${user.email}">Delete</button>
                        </td>
                    </tr>
                `;
                customerTableBody.append(userRow);
            }
        });

        // Delete user event
        $('.delete-user').click(function () {
            const email = $(this).data('email');
            const updatedUsers = users.filter(user => user.email !== email);
            localStorage.setItem('users', JSON.stringify(updatedUsers));
            alert('Customer deleted successfully!');
            loadCustomers();
        });
    }

    // Event listener for vendor search
    $('#vendorSearchBox').on('input', function () {
        const searchQuery = $(this).val();
        loadVendors(searchQuery);
    });

    // Event listener for customer search
    $('#customerSearchBox').on('input', function () {
        const searchQuery = $(this).val();
        loadCustomers(searchQuery);
    });

    // Load Admin Products
    function loadAdminProducts(priceRange = '') {
        const productTableBody = $('#productTable tbody').empty();

        products.forEach((product, index) => {
            const price = parseFloat(product.price);

            let [minPrice, maxPrice] = priceRange
                ? priceRange.split('-').map(Number)
                : [0, Infinity];

            if (price >= minPrice && price <= maxPrice) {
                const productRow = `
                    <tr>
                        <td>${index + 1}</td>
                        <td><img src="${product.image}" alt="Product Image" class="product-image"></td>
                        <td>${product.name}</td>
                        <td>$${price.toFixed(2)}</td>
                        <td>${product.vendorEmail}</td>
                        <td>
                            <button class="btn btn-warning btn-sm edit-product" data-id="${product.id}">Edit</button>
                            <button class="btn btn-danger btn-sm delete-product" data-id="${product.id}">Delete</button>
                        </td>
                    </tr>
                `;
                productTableBody.append(productRow);
            }
        });

        // Delete product event
        $('.delete-product').click(function () {
            const productId = $(this).data('id');
            const updatedProducts = products.filter(product => product.id !== productId);
            localStorage.setItem('products', JSON.stringify(updatedProducts));
            alert('Product deleted successfully!');
            loadAdminProducts(priceRange);
        });

        // Edit product event
        $('.edit-product').click(function () {
            const productId = $(this).data('id');
            const product = products.find(p => p.id === productId);

            if (product) {
                const newName = prompt('Edit product name:', product.name);
                const newPrice = parseFloat(prompt('Edit product price:', product.price));

                if (newName && !isNaN(newPrice)) {
                    product.name = newName.trim();
                    product.price = newPrice;
                    localStorage.setItem('products', JSON.stringify(products));
                    alert('Product updated successfully!');
                    loadAdminProducts(priceRange);
                } else {
                    alert('Invalid input! Product update canceled.');
                }
            }
        });
    }

    // Price range filter functionality
    $('#priceRangeFilter').on('change', function () {
        const selectedRange = $(this).val();
        loadAdminProducts(selectedRange);
    });

    // Initial data load
    loadVendors();
    loadCustomers();
    loadAdminProducts();
});
